# Ghazal-Store
You ask for simplicity, We deliver
